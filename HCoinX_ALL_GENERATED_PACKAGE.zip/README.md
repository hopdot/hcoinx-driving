# HCoinX – Full Generated Package

Includes:
- Smart contracts (HCX Slot Machine)
- GitHub Actions auto-deploy
- Web3 slot machine frontend
- PC game scaffold (HCoinX Drive)
- Deployment docs

## GitHub
Repo owner: @hopdot

## Deployment
Add secrets:
- ALCHEMY_API_KEY
- DEPLOYER_PRIVATE_KEY

Push to main to deploy.
